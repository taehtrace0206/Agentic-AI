---
title: "Connect from your IDE"
type: docs
weight: 1
description: >
  List of guides detailing how to connect your AI tools (IDEs) to Toolbox using MCP.
aliases:
- /how-to/connect_tools_using_mcp
---
