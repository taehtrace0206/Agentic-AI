---
title: "Cloud SQL for SQL Server using MCP"
type: docs
weight: 2
description: >
  Connect your IDE to Cloud SQL for SQL Server using Toolbox.
---
<html>
  <head>
    <link rel="canonical" href="https://cloud.google.com/sql/docs/sqlserver/pre-built-tools-with-mcp-toolbox"/>
    <meta http-equiv="refresh" content="0;url=https://cloud.google.com/sql/docs/sqlserver/pre-built-tools-with-mcp-toolbox"/>
  </head>
</html>
